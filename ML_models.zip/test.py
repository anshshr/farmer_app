from fastapi import FastAPI, HTTPException
import pandas as pd
import joblib
from pydantic import BaseModel
from geopy.geocoders import Nominatim
from pydantic import BaseModel
# Load the dataset
data = pd.read_csv('climate_change_upto_2000_1.csv')
app = FastAPI()

# Load pre-trained models
x_model = joblib.load('arabian_cyclone_model.pkl')  # Model for Arabian Sea region
y_model = joblib.load('sarima_cyclone_model.pkl')  # Model for Bay of Bengal region
z_model = joblib.load('land_cyclone_model.pkl')  # Model for Land Region
state_to_region = {
    # Arabian Sea States
    'Gujarat': 'Arabian Sea',
    'Maharashtra': 'Arabian Sea',
    'Goa': 'Arabian Sea',
    'Karnataka': 'Arabian Sea',
    'Kerala': 'Arabian Sea',
    # Arabian Sea Union Territories
    'Daman and Diu': 'Arabian Sea',
    'Lakshadweep': 'Arabian Sea',
    # Bay of Bengal States
    'Andhra Pradesh': 'Bay of Bengal',
    'Odisha': 'Bay of Bengal',
    'West Bengal': 'Bay of Bengal',
    'Tamil Nadu': 'Bay of Bengal',
    # Bay of Bengal Union Territories
    'Puducherry': 'Bay of Bengal',
    'Andaman and Nicobar Islands': 'Bay of Bengal',
    # Land Region (all other states and union territories)
    # Add more states/UTs as needed
}
# Pydantic model for request input
class CityInput(BaseModel):
    city: str

# Function to get state from city
def get_state_from_city(city):
    geolocator = Nominatim(user_agent="city_classifier")
    location = geolocator.geocode(city + ", India")
    if location:
        address = location.raw.get('address', {})
        state = address.get('state', '')
        if not state:
            # If state is not found, try to extract it from the display name
            display_name = location.raw.get('display_name', '')
            if ', Maharashtra,' in display_name:
                state = 'Maharashtra'
            elif ', Gujarat,' in display_name:
                state = 'Gujarat'
            elif ', Goa,' in display_name:
                state = 'Goa'
            elif ', Karnataka,' in display_name:
                state = 'Karnataka'
            elif ', Kerala,' in display_name:
                state = 'Kerala'
            elif ', Daman and Diu,' in display_name:
                state = 'Daman and Diu'
            elif ', Lakshadweep,' in display_name:
                state = 'Lakshadweep'
            elif ', Andhra Pradesh,' in display_name:
                state = 'Andhra Pradesh'
            elif ', Odisha,' in display_name:
                state = 'Odisha'
            elif ', West Bengal,' in display_name:
                state = 'West Bengal'
            elif ', Tamil Nadu,' in display_name:
                state = 'Tamil Nadu'
            elif ', Puducherry,' in display_name:
                state = 'Puducherry'
            elif ', Andaman and Nicobar Islands,' in display_name:
                state = 'Andaman and Nicobar Islands'
        return state
    else:
        raise ValueError(f"Could not find state for city: {city}")

# Function to classify region based on state
def classify_region(city):
    state = get_state_from_city(city)
    # Extract the state name (e.g., "Maharashtra" from "Mumbai Suburban, Maharashtra, India")
    state_name = state.split(',')[0].strip() if state else ''
    return state_to_region.get(state_name, 'Land Region')  # Default to Land Region if state not found

# Function to select model and dataset based on city
def select_model_and_dataset(city):
    region = classify_region(city)
    if region == 'Arabian Sea':
        return x_model, 'arabiancyclones.csv'
    elif region == 'Bay of Bengal':
        return y_model, 'bobcyclones.csv'
    else:
        return z_model, 'landcyclones.csv'

# Function to generate forecasts and return results
def generate_forecast(city):
    # Select model and dataset based on city
    model, dataset_file = select_model_and_dataset(city)

    # Load the dataset for the region
    data = pd.read_csv(dataset_file)

    # Remove rows where 'Year' is not a valid year (e.g., "Total ")
    data = data[data['Year'].astype(str).str.isdigit()]

    # Convert Year to datetime and set as index
    data['Year'] = pd.to_datetime(data['Year'], format='%Y')

    # Melt the data to create a seasonal time series
    seasonal_data = data.melt(id_vars=['Year'], value_vars=['JF', 'MAM', 'JJAS', 'OND'],
                              var_name='Season', value_name='Cyclone_Count')

    # Map seasons to months for proper datetime indexing
    season_to_month = {
        'JF': 1,   # January-February (use January as the start month)
        'MAM': 4,  # March-May (use March as the start month)
        'JJAS': 6, # June-September (use June as the start month)
        'OND': 10  # October-December (use October as the start month)
    }
    seasonal_data['Month'] = seasonal_data['Season'].map(season_to_month)

    # Create a datetime index for the seasonal data
    seasonal_data['Date'] = pd.to_datetime(seasonal_data['Year'].dt.year.astype(str) + '-' + seasonal_data['Month'].astype(str) + '-01')
    seasonal_data.set_index('Date', inplace=True)

    # Sort the data by date
    seasonal_data = seasonal_data.sort_index()

    # Explicitly set the frequency of the time series index
    seasonal_data = seasonal_data.asfreq('QS-JAN')  # Quarterly frequency starting in January

    # Use the 'Cyclone_Count' column as the seasonal time series
    time_series = seasonal_data['Cyclone_Count']

    # Forecast the next 8 seasons (2 years starting from 2025)
    forecast_steps = 8
    forecast = model.forecast(steps=forecast_steps)

    # Round forecasted values to whole numbers
    forecast = np.round(forecast).astype(int)

    # Create a DataFrame for the forecast
    forecast_years = [2025, 2025, 2025, 2025, 2026, 2026, 2026, 2026]  # Years for the forecast
    forecast_seasons = ['JF', 'MAM', 'JJAS', 'OND', 'JF', 'MAM', 'JJAS', 'OND']  # Seasons for the forecast

    forecast_df = pd.DataFrame({
        'Year': forecast_years,
        'Season': forecast_seasons,
        'Forecasted_Cyclone_Count': forecast
    })

    # Calculate cyclone probabilities
    max_cyclone_count = time_series.max()
    forecast_df['Cyclone_Probability'] = np.round((forecast_df['Forecasted_Cyclone_Count'] / max_cyclone_count) * 100).astype(int)

    # Convert forecast DataFrame to JSON
    forecast_json = forecast_df.to_dict(orient='records')

    return {
        "city": city,
        "region": classify_region(city),
        "forecast": forecast_json
    }

# FastAPI endpoint
@app.post("/forecast")
def forecast(city_input: CityInput):
    try:
        result = generate_forecast(city_input.city)
        return result
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# Preprocessing function
def preprocess_data(data, station):
    # Filter data for a specific station
    station_data = data[data['Station Name'] == station]

    # Convert Month to numerical format for sorting
    month_map = {'January': 1, 'February': 2, 'March': 3, 'April': 4,
                 'May': 5, 'June': 6, 'July': 7, 'August': 8,
                 'September': 9, 'October': 10, 'November': 11, 'December': 12}
    station_data['Month'] = station_data['Month'].map(month_map)

    # Sort by Month
    station_data = station_data.sort_values(by='Month')

    # Convert numeric months back to month names
    reverse_month_map = {v: k for k, v in month_map.items()}
    station_data['Month'] = station_data['Month'].map(reverse_month_map)

    return station_data


# FastAPI app
app = FastAPI()


# Pydantic model for response
class MonthData(BaseModel):
    Month: str
    Mean_Rainfall: float
    Mean_Temp_Min: float
    Mean_Temp_Max: float


# Endpoint to get month-wise data
@app.get("/monthwise-data/{station}", response_model=list[MonthData])
def get_monthwise_data(station: str):
    # Preprocess data for the station
    station_data = preprocess_data(data, station)

    if station_data.empty:
        raise HTTPException(status_code=404, detail=f"Station '{station}' not found")

    # Convert to list of dictionaries
    monthwise_data = []
    for _, row in station_data.iterrows():
        monthwise_data.append({
            "Month": row['Month'],
            "Mean_Rainfall": row['Mean Rainfall in mm'],
            "Mean_Temp_Min": row['Mean Temperature  in degree C - Minimum'],
            "Mean_Temp_Max": row['Mean Temperature in degree C - Maximum']
        })

    return monthwise_data


# Run the app
if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
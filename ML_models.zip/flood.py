from fastapi import FastAPI, HTTPException
import pandas as pd

# Initialize FastAPI app
app = FastAPI()

# Load and preprocess data
def load_and_preprocess_data():
    # Load the first CSV file
    flood_data = pd.read_csv('District_FloodedArea.csv')

    # Load the second CSV file
    impact_data = pd.read_csv('District_FloodImpact.csv')

    # Merge the dataframes on 'Dist_Name'
    merged_data = pd.merge(flood_data, impact_data, on='Dist_Name', how='inner')

    # Fill missing values in relevant columns
    merged_data['Population'] = merged_data['Population'].fillna(1)
    merged_data['Human_fatality'] = merged_data['Human_fatality'].fillna(0)
    merged_data['Mean_Flood_Duration'] = merged_data['Mean_Flood_Duration'].fillna(0)
    merged_data['Corrected_Percent_Flooded_Area'] = merged_data['Corrected_Percent_Flooded_Area'].fillna(0)

    # Calculate damage percentage
    merged_data['Damage_Percentage'] = (
        merged_data['Corrected_Percent_Flooded_Area'] *
        (1 + merged_data['Human_fatality'] / merged_data['Population']) *
        merged_data['Mean_Flood_Duration']
    )

    return merged_data

# Load data once when the app starts
data = load_and_preprocess_data()

# Define the root endpoint
@app.get("/")
def read_root():
    return {"message": "Welcome to the Flood Damage Prediction API!"}

# Define the prediction endpoint
@app.get("/predict-damage/")
def predict_damage(district: str):
    # Filter data for the input district
    district_data = data[data['Dist_Name'] == district]

    # Check if district exists in the data
    if district_data.empty:
        raise HTTPException(status_code=404, detail=f"District '{district}' not found in the data.")

    # Get the damage percentage
    damage_percentage = district_data['Damage_Percentage'].values[0]

    return {
        "district": district,
        "damage_percentage": f"{damage_percentage:.2f}%"
    }

# Run the app
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)